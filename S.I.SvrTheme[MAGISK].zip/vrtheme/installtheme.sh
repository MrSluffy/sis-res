#!/sbin/sh
# Copyright VillainROM 2011. All Rights Reserved
# Updated for Android JB, KK & L by Spannaa @ XDA 2014

# function to allow ui_print from sh
ui_print() { 
until [ ! "$1" ]; do 
echo -e "ui_print $1\nui_print" > $OUTFD; 
shift; 
done; 
}

bin=/data/tmp; 
chmod -R 755 $bin;

bb=/data/tmp/busybox

# function to select file locations based on rom version
set_paths(){
  dir="/$1"
	apk="$1.apk"
	dex="@$1"

}

# find which recovery is being used
cwm_run=$(ps | grep -v "grep" | grep -o -E "update_binary(.*)" | cut -d " " -f 3);
twrp_run=$(ps | grep -v "grep" | grep -o -E "updater(.*)" | cut -d " " -f 3);
if [ "$cwm_run" ]; then
	recovery_binary=$cwm_run
else
if [ "$twrp_run" ]; then
	recovery_binary=$twrp_run
fi
fi

# repeat for /system/priv-app
[ -d /data/tmp/vrtheme/system/priv-app ] && systemprivapps=1 || systemprivapps=0
if [ "$systemprivapps" -eq "1" ]; then
cd /data/tmp/vrtheme/system/priv-app/
ui_print "   Processing /system/priv-app"
for f in $(ls)
do
	set_paths $f
	ui_print "     $apk"
	$bb mkdir -p /data/tmp/ozop/system/priv-app$dir
	$bb mkdir -p /data/tmp/vrtheme/apply/system/priv-app$dir/aligned
# get apk
  cp /system/system/priv-app$dir/$apk /data/tmp/vrtheme/apply/system/priv-app$dir/
# backup apk
	cp /system/system/priv-app$dir/$apk /data/tmp/ozop/system/priv-app$dir/
# patch apk
	cd /data/tmp/vrtheme/system/priv-app$dir/$apk/
  /data/tmp/vrtheme/zip -r /data/tmp/vrtheme/apply/system/priv-app$dir/$apk *
# zipalign apk
	cd /data/tmp/vrtheme/apply/system/priv-app$dir/
	/data/tmp/vrtheme/zipalign -f 4 $apk aligned/$apk
# move apk back
	cp -rf aligned/$apk /system/system/priv-app$dir/
	chmod 0644 /system/priv-app$dir/$apk
# delete dalvik-cache entry if it exists
	dc_file=/data/dalvik-cache/arm/system@priv-app$dex@$apk@classes.dex
	if [ -f $dc_file ]; then
		rm -f $dc_file
	fi
done
fi

# repeat for /system/framework
[ -d /data/tmp/vrtheme/system/framework ] && framework=1 || framework=0
if [ "$framework" -eq "1" ]; then
  $bb mkdir -p /data/tmp/ozop/system/framework
	$bb mkdir -p /data/tmp/vrtheme/apply/system/framework/aligned
cd /data/tmp/vrtheme/system/framework
ui_print "   Processing /system/framework"
for f in $(ls)
do
	ui_print "     $f"
# get apk
  cp /system/system/framework/$f /data/tmp/vrtheme/apply/system/framework/
# backup apk
  cp /system/system/framework/$f /data/tmp/ozop/system/framework/
# patch apk
  cd /data/tmp/vrtheme/system/framework/$f/
  /data/tmp/vrtheme/zip -r /data/tmp/vrtheme/apply/system/framework/$f *
# zipalign apk
	cd /data/tmp/vrtheme/apply/system/framework/
# busybox mkdir aligned
	/data/tmp/vrtheme/zipalign -f 4 $f aligned/$f
# move apk back
	cp -rf aligned/$f /system/system/framework/
	chmod 644 /system/framework/$f
done
fi

# create restore zip from backup apks
if [ -d "/data/tmp/ozop" ]; then
	ui_print "   Creating ozop-restore.zip"
	cd /data/tmp/ozop/
  /data/tmp/vrtheme/zip -r /data/tmp/vrtheme/ozop_restore.zip *
	if [ -d "/sdcard/ozop" ]; then
		rm -f /sdcard/ozop/ozop_restore.zip
	else
		$bb mkdir -p /sdcard/ozop
	fi
	cp /data/tmp/vrtheme/ozop_restore.zip /sdcard/ozop/
	ui_print "   Restore zip created in /sdcard/ozop"
fi

# cleanup work files
ui_print "   Cleaning up work files"

$bb rm -fR /data/tmp/ozop
$bb rm -fR /data/tmp/vrtheme
